# PK232PY Cyberpunk + MFJ-1278 Patch

This package extends the previous cyberpunk Windows patch with a selectable **MFJ-1278 / MFJ-1278B** hardware profile and a double-click Windows build launcher.

## MFJ-1278 scope

The MFJ-1278 does **not** implement the AEA PK-232 binary Host Mode protocol used by PK232PY. This patch therefore provides safe first-stage support:

- Hardware selection is saved in `pk232py.ini`.
- MFJ-1278 connects through the existing serial terminal/command interface.
- PK-232 parameter upload is skipped for MFJ hardware.
- PK-232 Host Mode entry is blocked and redirected to terminal mode.
- Existing PK-232/PK-232MBX behavior is unchanged.

This is real terminal-level hardware compatibility, but it is not a claim that all ten PK-232 mode screens control every MFJ-1278 mode. Full MFJ native host-protocol support would require a separate MFJ protocol driver and hardware testing.

## Install

Place this patch folder anywhere, open PowerShell there, and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply_cyberpunk_mfj1278_patch.ps1 -ProjectRoot "D:\_projects\PK232py\PK232py-main"
```

Original modified files are backed up with `.original` extensions.

## Build

After applying, double-click:

```text
build.exe.bat
```

Despite its requested name, this is a Windows batch launcher, not a compiled executable. It creates the application executable at:

```text
dist\pk232py.exe
```

Python 3.13 is preferred. The build wrapper installs the missing `markdown` dependency before invoking Nuitka.


## Windows application icon

This package includes a real multi-resolution `pk232py.ico` containing 16, 24, 32, 48, 64, 128, and 256 pixel icon sizes. The patch copies it to the project root, adds it to the Nuitka executable build, and uses it for the Inno Setup installer and shortcuts. `pk232py_icon.png` is included as the 1024-pixel source artwork.
