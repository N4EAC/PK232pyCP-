param(
    [string]$Version = "0.1.0"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".\pyproject.toml")) {
    throw "Copy this script into the full PK232PY project root before running it."
}

# Prefer Python 3.13 for the current Nuitka/PyQt6 toolchain. Reuse an existing
# virtual environment when present so the user's setup is not destroyed.
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    $PyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if (-not $PyLauncher) {
        throw "Python launcher 'py' was not found. Install 64-bit Python 3.13 from python.org."
    }

    & py -3.13 -c "import sys" 2>$null
    if ($LASTEXITCODE -eq 0) {
        & py -3.13 -m venv .venv
    } else {
        Write-Warning "Python 3.13 was not found. Creating the environment with the default Python version."
        & py -3 -m venv .venv
    }
}

$Python = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

& $Python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed." }

# Install the project and build dependencies. The upstream Nuitka script asks
# for --include-package=markdown, but markdown is not listed in pyproject.toml.
& $Python -m pip install -e ".[dev]" nuitka markdown
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }

if (-not (Test-Path ".\build_windows.ps1")) {
    throw "The official build_windows.ps1 file is missing from the project root."
}

& .\build_windows.ps1 -Version $Version
if ($LASTEXITCODE -ne 0) {
    throw "PK232PY Windows build failed with exit code $LASTEXITCODE."
}
