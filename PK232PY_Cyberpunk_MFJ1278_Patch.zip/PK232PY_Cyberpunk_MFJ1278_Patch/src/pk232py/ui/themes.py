# pk232py - Modern multimode terminal for AEA PK-232 / PK-232MBX TNC
# Original project Copyright (C) 2026 OE3GAS — GPL v2
# Cyberpunk Windows appearance patch — GPL v2 compatible

"""Theme presets and QPalette construction for PK232PY.

This drop-in replacement preserves the original public API while adding a
Windows-oriented Cyberpunk preset and making it the first theme in the menu.
No modem, Host Mode, serial, macro, logging, or operating-mode logic is changed.
"""
from __future__ import annotations

from dataclasses import dataclass
from PyQt6.QtGui import QColor, QPalette


@dataclass(frozen=True)
class Theme:
    key: str
    name: str
    font_family: str
    font_size: int
    bg: str
    fg: str
    system_palette: bool


THEMES: dict[str, Theme] = {
    "cyberpunk": Theme(
        key="cyberpunk",
        name="Cyberpunk",
        font_family="Cascadia Mono SemiBold",
        font_size=13,
        bg="#070A12",
        fg="#27F5FF",
        system_palette=False,
    ),
    "dark": Theme(
        key="dark", name="Dark",
        font_family="Cascadia Mono SemiBold", font_size=14,
        bg="#1e1e1e", fg="#ffffff", system_palette=False,
    ),
    "mono": Theme(
        key="mono", name="Mono",
        font_family="Courier New", font_size=14,
        bg="#ffffff", fg="#1a1a1a", system_palette=False,
    ),
    "retro": Theme(
        key="retro", name="Retro",
        font_family="Courier New", font_size=14,
        bg="#0d0800", fg="#ffb000", system_palette=False,
    ),
    "air": Theme(
        key="air", name="Air",
        font_family="Segoe UI", font_size=11,
        bg="#ffffff", fg="#1a1a1a", system_palette=True,
    ),
}

THEME_ORDER: tuple[str, ...] = ("cyberpunk", "dark", "mono", "retro", "air")


def _shift(c: QColor, delta: int) -> QColor:
    def clamp(v: int) -> int:
        return max(0, min(255, v))
    return QColor(clamp(c.red() + delta), clamp(c.green() + delta), clamp(c.blue() + delta))


def _blend(a: QColor, b: QColor, t: float) -> QColor:
    return QColor(
        round(a.red() * (1 - t) + b.red() * t),
        round(a.green() * (1 - t) + b.green() * t),
        round(a.blue() * (1 - t) + b.blue() * t),
    )


def _luma(c: QColor) -> float:
    return 0.299 * c.red() + 0.587 * c.green() + 0.114 * c.blue()


def build_palette(theme: Theme) -> QPalette | None:
    if theme.system_palette:
        return None

    bg = QColor(theme.bg)
    fg = QColor(theme.fg)

    if theme.key == "cyberpunk":
        # Deep blue-black panels, cyan data text, violet selection and magenta alerts.
        window = QColor("#070A12")
        base = QColor("#03050B")
        alt_base = QColor("#0C1220")
        button = QColor("#10182A")
        tip_bg = QColor("#111A2E")
        highlight = QColor("#8A2BE2")
        highlighted_text = QColor("#FFFFFF")
        link = QColor("#FF3CAC")
        bright = QColor("#FF3CAC")
        placeholder = QColor("#5E8792")
        disabled = QColor("#50606B")
    elif _luma(bg) > 140:
        window = _shift(bg, -12)
        base = bg
        alt_base = _shift(bg, -10)
        button = _shift(bg, -28)
        tip_bg = _shift(bg, -16)
        highlight = _blend(fg, bg, 0.25)
        highlighted_text = bg
        link = highlight
        bright = QColor("#ff5555")
        placeholder = _blend(fg, bg, 0.5)
        disabled = _blend(fg, bg, 0.55)
    else:
        window = bg
        base = _shift(bg, -8)
        alt_base = _shift(bg, +6)
        button = _shift(bg, +28)
        tip_bg = _shift(bg, +28)
        highlight = _blend(fg, bg, 0.45)
        highlighted_text = bg
        link = highlight
        bright = QColor("#ff5555")
        placeholder = _blend(fg, bg, 0.5)
        disabled = _blend(fg, bg, 0.55)

    pal = QPalette()
    R = QPalette.ColorRole
    G = QPalette.ColorGroup
    pal.setColor(R.Window, window)
    pal.setColor(R.WindowText, fg)
    pal.setColor(R.Base, base)
    pal.setColor(R.AlternateBase, alt_base)
    pal.setColor(R.Text, fg)
    pal.setColor(R.Button, button)
    pal.setColor(R.ButtonText, fg)
    pal.setColor(R.BrightText, bright)
    pal.setColor(R.ToolTipBase, tip_bg)
    pal.setColor(R.ToolTipText, fg)
    pal.setColor(R.PlaceholderText, placeholder)
    pal.setColor(R.Highlight, highlight)
    pal.setColor(R.HighlightedText, highlighted_text)
    pal.setColor(R.Link, link)
    pal.setColor(R.LinkVisited, QColor("#C77DFF") if theme.key == "cyberpunk" else link)

    for role in (R.Text, R.ButtonText, R.WindowText):
        pal.setColor(G.Disabled, role, disabled)

    return pal
